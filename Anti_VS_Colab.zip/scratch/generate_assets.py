import zlib, struct, os, math

def create_png(width, height, pixels, filename):
    def chunk(tag, data):
        return struct.pack('!I', len(data)) + tag + data + struct.pack('!I', zlib.crc32(tag + data) & 0xffffffff)
    raw = bytearray()
    for y in range(height):
        raw.append(0)
        for x in range(width):
            raw.extend(pixels[y * width + x])
    ihdr = struct.pack('!IIBBBBB', width, height, 8, 6, 0, 0, 0)
    with open(filename, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n')
        f.write(chunk(b'IHDR', ihdr))
        f.write(chunk(b'IDAT', zlib.compress(bytes(raw))))
        f.write(chunk(b'IEND', b''))

# 1. Battle Axe (20x20)
axe = [(0,0,0,0)] * 400
for y in range(20):
    for x in range(20):
        # Handle (diagonal)
        if abs(x - y) <= 1 and 4 <= x <= 16:
            axe[y*20+x] = (130, 80, 40, 255)
        # Double-headed steel blade
        if (x - 14)**2 + (y - 6)**2 <= 20 or (x - 6)**2 + (y - 14)**2 <= 20:
            axe[y*20+x] = (180, 195, 215, 255)
            if (x - 14)**2 + (y - 6)**2 >= 16 or (x - 6)**2 + (y - 14)**2 >= 16:
                axe[y*20+x] = (245, 250, 255, 255) # razor edge
create_png(20, 20, axe, 'assets/sprites/proj_axe.png')

# 2. Celestial Arrow (20x10)
arrow = [(0,0,0,0)] * 200
for y in range(10):
    for x in range(20):
        # Shaft
        if y == 5 and 4 <= x <= 16:
            arrow[y*20+x] = (220, 180, 60, 255) # gold
        # Feathers
        if 1 <= x <= 4:
            if abs(y - 5) <= (5 - x):
                arrow[y*20+x] = (255, 255, 200, 220)
        # Arrowhead (Holy point)
        if 16 <= x <= 19:
            if abs(y - 5) <= (19 - x):
                arrow[y*20+x] = (255, 255, 255, 255)
        # Holy aura
        if abs(y - 5) <= 2 and 14 <= x <= 19:
            if arrow[y*20+x][3] == 0:
                arrow[y*20+x] = (255, 215, 0, 140)
create_png(20, 10, arrow, 'assets/sprites/proj_arrow.png')

# 3. Thunder Lightning Orb (20x20)
lightning = [(0,0,0,0)] * 400
for y in range(20):
    for x in range(20):
        d = math.hypot(x - 10, y - 10)
        if d <= 8:
            # Electric cyan core
            if d <= 3:
                lightning[y*20+x] = (240, 255, 255, 255) # bright core
            elif d <= 6:
                lightning[y*20+x] = (80, 220, 255, 240)
            else:
                lightning[y*20+x] = (30, 140, 255, 160)
        # Zigzag spark branches
        if abs(x - y) <= 1 and (2 <= x <= 6 or 13 <= x <= 17):
            lightning[y*20+x] = (220, 255, 255, 230)
create_png(20, 20, lightning, 'assets/sprites/proj_lightning.png')

# 4. Blood Dagger (18x18)
dagger = [(0,0,0,0)] * 324
for y in range(18):
    for x in range(18):
        # Diagonal dagger blade
        if abs(x - y) <= 1 and 6 <= x <= 16:
            dagger[y*18+x] = (220, 30, 50, 255) # ruby red
            if x == y:
                dagger[y*18+x] = (255, 120, 140, 255) # blood glint
        # Hilt & Guard
        if abs(x + y - 12) <= 2 and abs(x - y) <= 3 and 4 <= x <= 8:
            dagger[y*18+x] = (80, 15, 25, 255)
        # Handle
        if abs(x - y) <= 1 and 1 <= x <= 4:
            dagger[y*18+x] = (50, 10, 15, 255)
create_png(18, 18, dagger, 'assets/sprites/proj_dagger.png')

# 5. Death Scythe Blade (24x24)
scythe = [(0,0,0,0)] * 576
for y in range(24):
    for x in range(24):
        # Curved blade arc
        d = math.hypot(x - 5, y - 5)
        if 9 <= d <= 15 and x >= 5 and y >= 5:
            scythe[y*24+x] = (160, 40, 220, 255) # purple necrotic
            if d >= 14:
                scythe[y*24+x] = (240, 180, 255, 255) # glowing edge
        # Shaft
        if abs(x - y) <= 1 and 2 <= x <= 18:
            scythe[y*24+x] = (60, 45, 40, 255)
create_png(24, 24, scythe, 'assets/sprites/proj_scythe.png')

# 6. Bringer of Death Mob Sprite (32x32)
reaper = [(0,0,0,0)] * 1024
for y in range(32):
    for x in range(32):
        # Black hood/cloak
        if 6 <= y <= 28 and 8 <= x <= 24:
            if abs(x - 16) <= (y - 5) * 0.6:
                reaper[y*32+x] = (25, 20, 35, 255) # dark robe
                if abs(x - 16) <= 4 and y <= 16:
                    reaper[y*32+x] = (15, 10, 20, 255) # deep shadow in cowl
        # Horns / crown
        if y <= 8 and (abs(x - 12) <= 1 or abs(x - 20) <= 1):
            reaper[y*32+x] = (140, 30, 60, 255)
        # Glowing red demonic eyes
        if (y == 12 or y == 13) and (x == 13 or x == 19):
            reaper[y*32+x] = (255, 30, 40, 255)
        if y == 12 and (x == 14 or x == 18):
            reaper[y*32+x] = (255, 150, 160, 255)
        # Ghostly purple aura around bottom
        if 26 <= y <= 31 and 8 <= x <= 24:
            if abs(x - 16) <= 8 and reaper[y*32+x][3] == 0:
                reaper[y*32+x] = (120, 40, 200, 180)
create_png(32, 32, reaper, 'assets/sprites/mob_bringer_death.png')

print('All 6 sprites successfully created!')
