"""
Generate high quality thematic pixel art projectile sprites.
Theme: Grimdark gothic fantasy / holy paladin vs nether horrors.
No weird 'chairs' or thin sticks.
All projectiles are 32x32 with transparent background.
"""
import math
from PIL import Image, ImageDraw

def create_wind_blade():
    # Glowing crescent energy slash (Wind blade)
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    center = (16, 16)
    # Draw arc/crescent
    for angle_deg in range(-75, 76):
        rad = math.radians(angle_deg)
        # Outer curve
        r_out = 13.0 - (abs(angle_deg) / 75.0) * 4.0
        r_in = r_out - 4.5
        
        ox = center[0] + r_out * math.cos(rad)
        oy = center[1] + r_out * math.sin(rad)
        
        ix = center[0] + r_in * math.cos(rad)
        iy = center[1] + r_in * math.sin(rad)
        
        alpha_t = 1.0 - (abs(angle_deg) / 75.0) * 0.4
        
        # Soft outer glow
        draw.line([(ox, oy), (ix, iy)], fill=(120, 240, 255, int(180 * alpha_t)), width=3)
        # Bright core
        mx = (ox + ix) / 2.0
        my = (oy + iy) / 2.0
        draw.point((mx, my), fill=(255, 255, 255, int(255 * alpha_t)))

    # Core sharp blade edge
    for angle_deg in range(-65, 66):
        rad = math.radians(angle_deg)
        r = 12.0 - (abs(angle_deg) / 65.0) * 3.5
        x = center[0] + r * math.cos(rad)
        y = center[1] + r * math.sin(rad)
        draw.point((x, y), fill=(240, 255, 255, 255))
        draw.point((x - 1, y), fill=(100, 220, 255, 220))
        draw.point((x - 2, y), fill=(40, 160, 220, 160))

    return img

def create_holy_hammer():
    # Paladin Holy Warhammer - balanced head, ornate wings, gold/white glow
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Diagonal orientation (handle from (8, 24) to (18, 14))
    # Handle (wood + leather bands)
    draw.line([(8, 24), (18, 14)], fill=(110, 70, 40, 255), width=3)
    draw.line([(9, 23), (17, 15)], fill=(160, 110, 60, 255), width=1)
    # Gold Pommel
    draw.ellipse([(6, 23), (10, 27)], fill=(255, 215, 0, 255), outline=(180, 140, 0, 255))
    draw.point((8, 25), fill=(255, 255, 220, 255))
    
    # Ornate Hammerhead centered around (20, 12)
    # Gold Head Base
    draw.polygon([(15, 8), (25, 7), (26, 17), (16, 18)], fill=(255, 200, 30, 255))
    draw.polygon([(16, 9), (24, 8), (25, 16), (17, 17)], fill=(255, 230, 100, 255))
    # Silver Impact Faces
    draw.polygon([(24, 6), (28, 8), (28, 15), (25, 17)], fill=(230, 240, 255, 255))
    draw.polygon([(14, 8), (17, 6), (18, 18), (13, 16)], fill=(200, 210, 230, 255))
    # Glowing Cross / Holy Sun Core
    draw.line([(20, 10), (22, 14)], fill=(255, 255, 255, 255), width=2)
    draw.line([(19, 13), (23, 11)], fill=(255, 255, 255, 255), width=2)
    # Holy Aura halo
    for r in range(1, 4):
        draw.ellipse([(14 - r, 6 - r), (28 + r, 18 + r)], outline=(255, 230, 80, 50 - r * 15))
    return img

def create_ice_shard():
    # Pristine crystalline ice spear / shard
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Horizontal/pointed right: Tip at (29, 16), back at (4, 16)
    pts_top = [(5, 16), (14, 11), (28, 16)]
    pts_bot = [(5, 16), (14, 21), (28, 16)]
    draw.polygon(pts_top, fill=(160, 220, 255, 230))
    draw.polygon(pts_bot, fill=(90, 160, 230, 230))
    # Facet line
    draw.line([(5, 16), (29, 16)], fill=(255, 255, 255, 255), width=2)
    # Diamond facets
    draw.polygon([(10, 16), (15, 12), (20, 16), (15, 20)], fill=(220, 245, 255, 240))
    # Glowing frost sparkles
    draw.point((26, 15), fill=(255, 255, 255, 255))
    draw.point((15, 14), fill=(255, 255, 255, 255))
    draw.point((17, 18), fill=(255, 255, 255, 255))
    # Outer frost glow
    for x in range(32):
        for y in range(32):
            dx = (x - 16)
            dy = (y - 16) * 1.8
            d = math.hypot(dx, dy)
            if 7 <= d <= 13:
                r, g, b, a = img.getpixel((x, y))
                if a == 0:
                    img.putpixel((x, y), (140, 210, 255, int(45 * (1.0 - (d - 7) / 6.0))))
    return img

def create_executioner_axe():
    # Double-headed battleaxe
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Handle diagonal (7, 25) to (21, 11)
    draw.line([(7, 25), (22, 10)], fill=(80, 50, 30, 255), width=3)
    draw.line([(8, 24), (21, 11)], fill=(120, 80, 50, 255), width=1)
    # Steel blades on both sides of head at (18, 14)
    # Blade 1 (Upper left)
    draw.polygon([(15, 12), (9, 7), (13, 3), (20, 9)], fill=(180, 190, 205, 255))
    draw.line([(9, 7), (13, 3)], fill=(240, 245, 255, 255), width=2)
    # Blade 2 (Lower right)
    draw.polygon([(19, 16), (23, 22), (27, 18), (21, 13)], fill=(180, 190, 205, 255))
    draw.line([(23, 22), (27, 18)], fill=(240, 245, 255, 255), width=2)
    # Golden ring socket
    draw.ellipse([(15, 10), (21, 16)], fill=(220, 170, 40, 255))
    # Crimson rune gem
    draw.ellipse([(17, 12), (19, 14)], fill=(220, 30, 30, 255))
    return img

def create_celestial_arrow():
    # Luminous holy arrow
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Pointing right: Tip at (29, 16), tail at (4, 16)
    # Shaft of solid light
    draw.line([(5, 16), (27, 16)], fill=(255, 240, 180, 255), width=2)
    draw.line([(7, 16), (26, 16)], fill=(255, 255, 255, 255), width=1)
    # Arrowhead
    draw.polygon([(23, 11), (30, 16), (23, 21), (25, 16)], fill=(255, 220, 60, 255))
    draw.polygon([(24, 13), (29, 16), (24, 19), (26, 16)], fill=(255, 255, 255, 255))
    # Fletching (golden angel feathers)
    draw.line([(5, 16), (2, 12)], fill=(255, 215, 80, 255), width=2)
    draw.line([(5, 16), (2, 20)], fill=(255, 215, 80, 255), width=2)
    draw.line([(8, 16), (5, 12)], fill=(255, 235, 140, 255), width=2)
    draw.line([(8, 16), (5, 20)], fill=(255, 235, 140, 255), width=2)
    # Glow aura
    for r in range(1, 3):
        draw.ellipse([(20 - r, 12 - r), (31 + r, 20 + r)], outline=(255, 230, 100, 60 - r * 20))
    return img

def create_lightning_bolt():
    # Jagged crackling storm bolt
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    pts = [(4, 7), (13, 11), (10, 15), (20, 18), (17, 21), (28, 25)]
    # Blue/cyan outer glow
    for i in range(len(pts) - 1):
        draw.line([pts[i], pts[i+1]], fill=(60, 180, 255, 180), width=4)
    # Bright cyan
    for i in range(len(pts) - 1):
        draw.line([pts[i], pts[i+1]], fill=(160, 240, 255, 240), width=2)
    # Pure white core
    for i in range(len(pts) - 1):
        draw.line([pts[i], pts[i+1]], fill=(255, 255, 255, 255), width=1)
    # Secondary spark branch
    draw.line([(13, 11), (18, 8)], fill=(120, 220, 255, 220), width=1)
    draw.line([(20, 18), (22, 24)], fill=(120, 220, 255, 220), width=1)
    return img

def create_magic_orb():
    # Arcane cosmic vortex orb
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    center = (16, 16)
    # Soft purple aura
    for r in range(12, 5, -1):
        alpha = int(25 + (12 - r) * 22)
        draw.ellipse([(center[0] - r, center[1] - r), (center[0] + r, center[1] + r)], fill=(140, 30, 240, alpha))
    # Magenta mid ring
    draw.ellipse([(center[0] - 6, center[1] - 6), (center[0] + 6, center[1] + 6)], fill=(220, 60, 240, 220))
    # Violet core
    draw.ellipse([(center[0] - 4, center[1] - 4), (center[0] + 4, center[1] + 4)], fill=(250, 160, 255, 255))
    # White star highlight
    draw.line([(center[0] - 3, center[1]), (center[0] + 3, center[1])], fill=(255, 255, 255, 255), width=1)
    draw.line([(center[0], center[1] - 3), (center[0], center[1] + 3)], fill=(255, 255, 255, 255), width=1)
    return img

def create_fire_comet():
    # Fiery blazing comet
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Flame tail pointing left, head on right at (22, 16)
    # Outer dark red flame
    draw.polygon([(6, 12), (18, 9), (26, 16), (18, 23), (5, 19), (12, 16)], fill=(220, 40, 10, 180))
    # Bright orange core
    draw.polygon([(11, 13), (19, 11), (25, 16), (19, 21), (10, 18), (14, 16)], fill=(255, 130, 20, 230))
    # Yellow hot center
    draw.polygon([(16, 14), (21, 13), (24, 16), (21, 19), (15, 17)], fill=(255, 220, 50, 255))
    # White incandescent tip
    draw.ellipse([(20, 14), (24, 18)], fill=(255, 255, 240, 255))
    # Floating embers
    draw.point((4, 10), fill=(255, 160, 30, 200))
    draw.point((2, 16), fill=(255, 80, 20, 180))
    draw.point((5, 22), fill=(255, 180, 40, 220))
    return img

def create_poison_globule():
    # Acidic venom droplet / skull orb
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    center = (16, 16)
    # Toxic green outer slime
    for r in range(11, 4, -1):
        alpha = int(30 + (11 - r) * 25)
        draw.ellipse([(center[0] - r, center[1] - r), (center[0] + r, center[1] + r)], fill=(30, 190, 40, alpha))
    # Lime body
    draw.ellipse([(center[0] - 6, center[1] - 6), (center[0] + 6, center[1] + 6)], fill=(70, 240, 60, 240))
    # Toxic skull / bubbles
    draw.ellipse([(14, 13), (16, 15)], fill=(20, 80, 20, 255))
    draw.ellipse([(18, 13), (20, 15)], fill=(20, 80, 20, 255))
    draw.polygon([(16, 17), (18, 17), (17, 19)], fill=(20, 80, 20, 255))
    # Acid drip highlight
    draw.point((13, 11), fill=(220, 255, 200, 255))
    draw.point((14, 10), fill=(220, 255, 200, 255))
    return img

def create_reaper_scythe():
    # Curved obsidian scythe blade with purple mist
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Handle diagonal
    draw.line([(8, 25), (17, 13)], fill=(50, 40, 45, 255), width=2)
    # Curved blade from (17, 13) curling around to (28, 8) and tip at (24, 21)
    pts_outer = [(16, 12), (20, 8), (26, 8), (28, 12), (26, 19), (21, 23)]
    pts_inner = [(18, 13), (22, 11), (25, 13), (24, 17), (21, 23)]
    draw.polygon(pts_outer, fill=(40, 25, 55, 255))
    draw.polygon(pts_inner, fill=(70, 40, 95, 255))
    # Razor blade edge
    draw.line([(20, 8), (26, 8), (28, 12), (26, 19), (21, 23)], fill=(190, 140, 255, 255), width=1)
    draw.point((21, 23), fill=(255, 255, 255, 255))
    # Spectral mist
    draw.ellipse([(19, 10), (25, 16)], outline=(160, 60, 255, 90))
    return img

generators = {
    'proj_wind.png': create_wind_blade,
    'proj_holy.png': create_holy_hammer,
    'proj_ice.png': create_ice_shard,
    'proj_axe.png': create_executioner_axe,
    'proj_arrow.png': create_celestial_arrow,
    'proj_lightning.png': create_lightning_bolt,
    'proj_magic.png': create_magic_orb,
    'proj_fire.png': create_fire_comet,
    'proj_poison.png': create_poison_globule,
    'proj_scythe.png': create_reaper_scythe,
}

import os
os.makedirs('assets/sprites', exist_ok=True)
for filename, gen in generators.items():
    p = os.path.join('assets/sprites', filename)
    img = gen()
    img.save(p)
    print(f"Generated {filename}: {img.size}")
