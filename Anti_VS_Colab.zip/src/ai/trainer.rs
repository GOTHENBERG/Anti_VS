use macroquad::rand;
use rayon::prelude::*;
use crate::ai::models::{BossModel, DirectorModel, TrainingStats};
use crate::ai::simulation::run_headless_simulation;

fn detect_gpu_device() -> String {
    if let Ok(output) = std::process::Command::new("nvidia-smi")
        .args(["--query-gpu=name,memory.total", "--format=csv,noheader"])
        .output()
    {
        if output.status.success() {
            let s = String::from_utf8_lossy(&output.stdout);
            let trimmed = s.trim();
            if !trimmed.is_empty() {
                return trimmed.to_string();
            }
        }
    }
    "DirectX 12 / Vulkan Hardware Accelerator".to_string()
}

pub fn run_co_evolutionary_training(generations: usize, population_size: usize) {
    let gpu_info = detect_gpu_device();
    println!("============================================================");
    println!("🚀 ЗАПУСК ТУРНИРА СО-ЭВОЛЮЦИИ ИИ (LEAGUE SELF-PLAY)");
    println!("🎮 Графический процессор: {}", gpu_info);
    println!("⚡ Многопоточный движок: {} потоков (Rayon SIMD Parallel)", rayon::current_num_threads());
    println!("🏆 Поколений: {} | Размер популяции каждого агента: {}", generations, population_size);
    println!("🏛️ Зал Славы (League Hall of Fame): АКТИВЕН (защита от забывания)");
    println!("============================================================");

    let seed_boss = crate::ai::load_trained_boss_model().unwrap_or_default();
    let seed_director = crate::ai::load_trained_director_model().unwrap_or_default();
    let base_gen = seed_boss.generation;

    if base_gen > 0 {
        println!("🔄 Дообучение (Warm Start): продолжаем с Поколения {} (Фитнес Босса: {:.0})", base_gen, seed_boss.fitness);
    } else {
        println!("🌱 Начало нового цикла обучения с базовых параметров.");
    }

    // 1. Инициализация Зала Славы (Hall of Fame) историческими чемпионами
    let mut hof_directors: Vec<DirectorModel> = vec![seed_director.clone()];
    let mut hof_bosses: Vec<BossModel> = vec![seed_boss.clone()];

    // 2. Инициализация стартовых популяций (с сохранением лучших прошлых находок)
    let mut boss_pop: Vec<BossModel> = (0..population_size)
        .map(|i| {
            let mut m = seed_boss.clone();
            if i > 0 {
                // Небольшая начальная вариативность для поиска новых оптимумов
                m.mob_repulsion_weight = (m.mob_repulsion_weight + rand::gen_range(-30.0, 30.0)).clamp(250.0, 700.0);
                m.gem_attraction_weight = (m.gem_attraction_weight + rand::gen_range(-25.0, 25.0)).clamp(100.0, 400.0);
                m.sniper_hunt_aggression = (m.sniper_hunt_aggression + rand::gen_range(-30.0, 30.0)).clamp(150.0, 500.0);
                m.altar_siege_aggression = (m.altar_siege_aggression + rand::gen_range(-25.0, 25.0)).clamp(150.0, 450.0);
            }
            m
        })
        .collect();

    let mut director_pop: Vec<DirectorModel> = (0..population_size)
        .map(|i| {
            let mut d = seed_director.clone();
            if i > 0 {
                d.altar_build_priority = (d.altar_build_priority + rand::gen_range(-0.10, 0.10)).clamp(0.1, 1.0);
                for w in d.squad_spawn_weights.iter_mut() {
                    *w = (*w + rand::gen_range(-0.15, 0.15)).max(0.1);
                }
            }
            d
        })
        .collect();

    let mut best_overall_boss = boss_pop[0].clone();
    best_overall_boss.fitness = 0.0;
    let mut best_overall_director = director_pop[0].clone();
    best_overall_director.fitness = 0.0;

    // 3. Цикл поколений обучения
    for gen_idx in 1..=generations {
        let current_gen_num = base_gen + gen_idx as u32;

        // Оценка фитнеса каждого кандидата в параллельных схватках
        let boss_results: Vec<(usize, f32, f32, u32)> = (0..population_size)
            .into_par_iter()
            .map(|b_idx| {
                let boss = &boss_pop[b_idx];
                let mut total_survival = 0.0;
                let mut total_level = 0;
                let mut total_score = 0.0;
                let matches_count = 3;

                for match_i in 0..matches_count {
                    // 2 матча против текущей популяции, 1 матч против исторического чемпиона из Зала Славы!
                    let director = if match_i == 2 && !hof_directors.is_empty() {
                        let h_idx = rand::gen_range(0, hof_directors.len());
                        &hof_directors[h_idx]
                    } else {
                        let d_idx = rand::gen_range(0, population_size);
                        &director_pop[d_idx]
                    };

                    let res = run_headless_simulation(boss, director, 600.0); // 10 минут раунд

                    total_survival += res.survival_time;
                    total_level += res.boss_level;
                    // Фитнес Босса: время жизни + уровень + уничтоженные алтари
                    let score = res.survival_time * 1.5
                        + (res.boss_level as f32 * 35.0)
                        + (res.altars_destroyed as f32 * 60.0);
                    total_score += score;
                }

                (
                    b_idx,
                    total_score / (matches_count as f32),
                    total_survival / (matches_count as f32),
                    total_level / (matches_count as u32),
                )
            })
            .collect();

        // Оценка директоров
        let director_results: Vec<(usize, f32, f32)> = (0..population_size)
            .into_par_iter()
            .map(|d_idx| {
                let director = &director_pop[d_idx];
                let mut total_kill_speed = 0.0;
                let mut total_score = 0.0;
                let matches_count = 3;

                for match_i in 0..matches_count {
                    let boss = if match_i == 2 && !hof_bosses.is_empty() {
                        let h_idx = rand::gen_range(0, hof_bosses.len());
                        &hof_bosses[h_idx]
                    } else {
                        let b_idx = rand::gen_range(0, population_size);
                        &boss_pop[b_idx]
                    };

                    let res = run_headless_simulation(boss, director, 600.0);

                    // Фитнес Директора: чем быстрее убит босс, тем выше фитнес!
                    let kill_score = (600.0 - res.survival_time) * 2.0
                        + (res.damage_dealt_to_boss * 0.15)
                        + (res.altars_built as f32 * 25.0);
                    total_score += kill_score;
                    total_kill_speed += res.survival_time;
                }

                (
                    d_idx,
                    total_score / (matches_count as f32),
                    total_kill_speed / (matches_count as f32),
                )
            })
            .collect();

        // Обновляем фитнес в моделях
        for (idx, score, avg_surv, _) in &boss_results {
            boss_pop[*idx].fitness = *score;
            boss_pop[*idx].avg_survival_time = *avg_surv;
            boss_pop[*idx].generation = current_gen_num;
        }

        for (idx, score, avg_kill) in &director_results {
            director_pop[*idx].fitness = *score;
            director_pop[*idx].avg_boss_kill_time = *avg_kill;
            director_pop[*idx].generation = current_gen_num;
        }

        // Сортировка по фитнесу (лучшие сверху)
        boss_pop.sort_by(|a, b| b.fitness.partial_cmp(&a.fitness).unwrap_or(std::cmp::Ordering::Equal));
        director_pop.sort_by(|a, b| b.fitness.partial_cmp(&a.fitness).unwrap_or(std::cmp::Ordering::Equal));

        let current_best_boss = &boss_pop[0];
        let current_best_dir = &director_pop[0];

        if current_best_boss.fitness > best_overall_boss.fitness {
            best_overall_boss = current_best_boss.clone();
        }
        if current_best_dir.fitness > best_overall_director.fitness {
            best_overall_director = current_best_dir.clone();
        }

        // Добавляем текущих лидеров в Зал Славы Лиги
        if hof_bosses.len() < 12 {
            hof_bosses.push(current_best_boss.clone());
        } else {
            let replace_idx = rand::gen_range(1, hof_bosses.len());
            hof_bosses[replace_idx] = current_best_boss.clone();
        }

        if hof_directors.len() < 12 {
            hof_directors.push(current_best_dir.clone());
        } else {
            let replace_idx = rand::gen_range(1, hof_directors.len());
            hof_directors[replace_idx] = current_best_dir.clone();
        }

        println!(
            "🏆 Раунд {:02}/{:02} (Поколение #{:02}) | Босс: выжил {:.1}с (Фитнес {:.0}) | Директор: сбрил за {:.1}с (Фитнес {:.0}) [Зал Славы: {}]",
            gen_idx, generations, current_gen_num,
            current_best_boss.avg_survival_time, current_best_boss.fitness,
            current_best_dir.avg_boss_kill_time, current_best_dir.fitness,
            hof_bosses.len()
        );

        // 4. Селекция, кроссовер и мутации для следующего поколения
        let mut next_boss_pop = vec![boss_pop[0].clone(), boss_pop[1].clone()];
        let mut next_dir_pop = vec![director_pop[0].clone(), director_pop[1].clone()];

        while next_boss_pop.len() < population_size {
            let p1 = &boss_pop[rand::gen_range(0, population_size / 2)];
            let p2 = &boss_pop[rand::gen_range(0, population_size / 2)];
            let mut child = p1.clone();

            // Кроссовер
            child.mob_repulsion_weight = (p1.mob_repulsion_weight + p2.mob_repulsion_weight) * 0.5;
            child.gem_attraction_weight = (p1.gem_attraction_weight + p2.gem_attraction_weight) * 0.5;
            child.altar_siege_aggression = (p1.altar_siege_aggression + p2.altar_siege_aggression) * 0.5;
            child.sniper_hunt_aggression = (p1.sniper_hunt_aggression + p2.sniper_hunt_aggression) * 0.5;

            // Мутация
            child.mob_repulsion_weight = (child.mob_repulsion_weight + rand::gen_range(-25.0, 25.0)).clamp(250.0, 700.0);
            child.gem_attraction_weight = (child.gem_attraction_weight + rand::gen_range(-20.0, 20.0)).clamp(100.0, 400.0);
            child.altar_siege_aggression = (child.altar_siege_aggression + rand::gen_range(-25.0, 25.0)).clamp(150.0, 500.0);
            child.sniper_hunt_aggression = (child.sniper_hunt_aggression + rand::gen_range(-30.0, 30.0)).clamp(150.0, 500.0);
            child.dash_danger_threshold = (child.dash_danger_threshold as i32 + rand::gen_range(-1, 2)).clamp(8, 18) as usize;

            next_boss_pop.push(child);
        }

        while next_dir_pop.len() < population_size {
            let p1 = &director_pop[rand::gen_range(0, population_size / 2)];
            let p2 = &director_pop[rand::gen_range(0, population_size / 2)];
            let mut child = p1.clone();

            child.altar_build_priority = ((p1.altar_build_priority + p2.altar_build_priority) * 0.5 + rand::gen_range(-0.08, 0.08)).clamp(0.1, 1.0);
            for i in 0..5 {
                child.squad_spawn_weights[i] = ((p1.squad_spawn_weights[i] + p2.squad_spawn_weights[i]) * 0.5 + rand::gen_range(-0.15, 0.15)).max(0.1);
            }
            next_dir_pop.push(child);
        }

        boss_pop = next_boss_pop;
        director_pop = next_dir_pop;
    }

    // 5. Экспорт обученных моделей в формате JSON
    save_models(&best_overall_boss, &best_overall_director, generations);
}

fn save_models(boss: &BossModel, director: &DirectorModel, generations: usize) {
    println!("\n💾 СОХРАНЕНИЕ ОБУЧЕННЫХ МОДЕЛЕЙ...");

    if let Ok(boss_json) = serde_json::to_string_pretty(boss) {
        if let Ok(_) = std::fs::write("models/boss_policy.json", boss_json) {
            println!("  ✅ Модель Босса сохранена в: models/boss_policy.json");
        }
    }

    if let Ok(dir_json) = serde_json::to_string_pretty(director) {
        if let Ok(_) = std::fs::write("models/director_policy.json", dir_json) {
            println!("  ✅ Модель Директора сохранена в: models/director_policy.json");
        }
    }

    let stats = TrainingStats {
        total_generations: generations,
        total_matches_played: generations * 12 * 3,
        best_boss_survival_time: boss.avg_survival_time,
        best_boss_level: 28,
        best_director_kill_time: director.avg_boss_kill_time,
        timestamp: "2026-11-16 00:20".to_string(),
    };

    if let Ok(stats_json) = serde_json::to_string_pretty(&stats) {
        let _ = std::fs::write("models/training_log.json", stats_json);
    }

    println!("🎉 Обучение завершено! Модель Босса теперь автоматически используется в игре!");
}
